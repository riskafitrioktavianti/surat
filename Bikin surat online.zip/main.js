function popupku() {
  var body = document.querySelector("body");
  var pWm = document.createElement("a");
  pWm.setAttribute("href", "https://instagram.com/abay_sptrr?igshid=YmMyMTA2M2Y=");
  pWm.setAttribute("style", "text-decoration: none; color: white; opacity: .5; position: fixed; bottom : 10px; left: 10px");
  pWm.innerHTML = "Instagram : @abay_sptrr";
  body.appendChild(pWm);
}
